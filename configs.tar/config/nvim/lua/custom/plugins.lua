local overrides = require("custom.configs.overrides")

---@type NvPluginSpec[]
local plugins = {

        -- Override plugin definition options
        {
                "mhartington/formatter.nvim",
                event = "VeryLazy",
                opts = function()
                        return require "custom.configs.formatter"
                end
        },

        {
                "christoomey/vim-tmux-navigator",
                lazy = false,
        },

        {
                "michaelrommel/nvim-silicon",
                lazy = true,
                cmd = "Silicon",
                init = function()
                        local wk = require("which-key")
                        wk.register({
                                ["<leader>sc"] = { ":Silicon<CR>", "Snapshot Code" },
                        }, { mode = "v" })
                end,
                config = function()
                        require("silicon").setup({
                                font = "JetBrainsMono Nerd Font=34;Noto Color Emoji=34",
                                theme = "Dracula",
                                background = "#94e2d5",
                        })
                end
        },

        {
                "mfussenegger/nvim-lint",
                event = "VeryLazy",
                config= function()
                        require "custom.configs.lint"
                end
        },

        {
                "neovim/nvim-lspconfig",
                config = function()
                        require "plugins.configs.lspconfig"
                        require "custom.configs.lspconfig"
                end, -- Override to setup mason-lspconfig
        },

        -- override plugin configs
        {
                "williamboman/mason.nvim",
                opts = {
                        ensure_installed = {
                                "prettier",
                                "erb-lint",
                                "eslint-lsp",
                                "ruby-lsp",
                                "typescript-language-server",
                                "tailwindcss-language-server",
                                "pyright",
                                "debugpy",
                        },
                },
        },

        {
                "nvim-treesitter/nvim-treesitter",
                opts = {
                        ensure_installed = {
                                -- defaults
                                "vim",
                                "lua",

                                -- webdev
                                "html",
                                "css",
                                "javascript",
                                "typescript",
                                "ruby",
                                "tsx",
                                "json",
                                "ruby",

                                -- low level
                                "c",
                                "python",
                                "cpp"
                        },
                },
        },

        {
                "nvim-tree/nvim-tree.lua",
                opts = overrides.nvimtree,
        },

        -- Install a plugin
        {
                "max397574/better-escape.nvim",
                event = "InsertEnter",
                config = function()
                        require("better_escape").setup()
                end,
        },

        {
                "stevearc/conform.nvim",
                --  for users those who want auto-save conform + lazyloading!
                -- event = "BufWritePre"
                config = function()
                        require "custom.configs.conform"
                end,
        },

        {
                "windwp/nvim-ts-autotag",
                ft = {
                        "javascript",
                        "javascriptreact",
                        "typescript",
                        "typescriptreact",
                        "html",
                },
                config = function ()
                        require("nvim-ts-autotag").setup()
                end
        },


        -- Trying to add dadbo again, comment it out
        -- {
                -- "tpope/vim-dadbod",
                -- opt = true,
                -- requires = {
                        -- "kristijanhusak/vim-dadbod-ui",
                        -- "kristijanhusak/vim-dadbod-completion",
                -- },
                -- config = function()
                        -- require("config.dadbod").setup()
                -- end,
                -- cmd = { "DBUIToggle", "DBUI", "DBUIAddConnection", "DBUIFindBuffer", "DBUIRenameBuffer", "DBUILastQueryInfo" },
        -- }
        {
                "nvim-neotest/nvim-nio",
        },

        {
                "mfussenegger/nvim-dap",
                init = function()
                        require("core.utils").load_mappings("dap")
                end
        },

        {
                "mfussenegger/nvim-dap-python",
                ft = "python",
                dependencies = {
                        "mfussenegger/nvim-dap",
                        "rcarriga/nvim-dap-ui",
                        "nvim-neotest/nvim-nio"
                },
                config = function(_, opts)
                        local path = "~/.local/share/nvim/mason/packages/debugpy/venv/bin/python"
                        require("dap-python").setup(path)
                        require("core.utils").load_mappings("dap_python")
                end,
        },

        {
                "leoluz/nvim-dap-go",
                ft = "go",
                dependencies = "mfussenegger/nvim-dap",
                config = function(_, opts)
                        require("dap-go").setup(opts)
                        require("core.utils").load_mappings("dap_go")
                end
        },

        {
                "theHamsta/nvim-dap-virtual-text",
                lazy = false,
                config = function(_, opts)
                        require("nvim-dap-virtual-text").setup()
                end
        },

        {
                "rcarriga/nvim-dap-ui",
                dependencies = "mfussenegger/nvim-dap",
                config = function()
                local dap = require("dap")
                local dapui = require("dapui")
                dapui.setup()
                dap.listeners.after.event_initialized["dapui_config"] = function ()
                        dapui.open()
                end
                dap.listeners.before.event_terminated["dapui_config"] = function ()
                        dapui.close()
                end
                dap.listeners.before.event_exited["dapui_config"] = function ()
                        dapui.close()
                end
                end
        },

        -- To make a plugin not be loaded
        -- {
        --   "NvChad/nvim-colorizer.lua",
        --   enabled = false
        -- },

        -- All NvChad plugins are lazy-loaded by default
        -- For a plugin to be loaded, you will need to set either `ft`, `cmd`, `keys`, `event`, or set `lazy = false`
        -- If you want a plugin to load on startup, add `lazy = false` to a plugin spec, for example
        -- {
        --   "mg979/vim-visual-multi",
        --   lazy = false,
        -- }
}

return plugins
